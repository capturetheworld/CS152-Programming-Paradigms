package value

trait Value