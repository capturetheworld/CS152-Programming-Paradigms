package context

import value.Value
import expression.Identifier

class Environment extends collection.mutable.HashMap[Identifier, Value]
